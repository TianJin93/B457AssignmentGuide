按照guide实现。
第4题实现完成后，写一个单独的txt放找到的值
第二题中的link有问题，用下面这个
http://scikit-image.org/docs/dev/auto_examples/edges/plot_canny.html