Follow the guide.
Put all the code and result in a zip file.