老师补充1:
Even with an efficient implementation, the gradient computation and optical flow extraction of PA8 can take a good amount of computation time. In order to reduce this, you may do feature extraction for every 6 frames instead of using them all. That is, you are free to process the video with the 5 fps setting instead of the current 30 fps setting.

老师补充2:
Please use the following URL to get the frame sequences for PA8:
http://homes.soic.indiana.edu/classes/spring2017/csci/b457-mryoo/jpl.zip 

老师补充3:
Here's the URL for smaller jpg frame sequences:
http://homes.soic.indiana.edu/classes/spring2017/csci/b457-mryoo/jpl-jpg.zip 
Feel free to use whichever one you want to use.
Also, feel free to rename the folder "4_4_1 as 4_4" and "4_4_2 as 3_4" to make their processing simpler.

补充内容很有用，link中需要下载的文件比较大。如果国内网速不行你告诉我，我传到云盘。
这个作业整体难度最大，不要求全部正确，但是要80%以上完成度。尽可能的多的实现
problem2 可以网上找一些code。