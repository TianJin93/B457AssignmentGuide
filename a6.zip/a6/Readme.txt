查看leture7_1 和lecture8_1 的ppt（在a5.zip中已有）
可能需要用到pa3中的内容，pa3的作业guide和满分作业也在文件夹内
