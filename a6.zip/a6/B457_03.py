#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 27 13:49:02 2017

@author: aiyxu
"""
from PIL import Image
from pylab import *
import matplotlib.pyplot as plt
import matplotlib.colors 
from scipy.cluster.vq import *
import numpy as np
import random

######################### problem1: K-means clustering ########################

#1: generate 3 class in 2-D space

class1 = 2.0 * np.random.randn(100,2)
class2 = np.random.randn(100,2) + np.array([5,5])
class3 = np.random.randn(100,2) + np.array([5,0])

#2: Use K-means to visulize the results
features = np.vstack((class1,class2,class3))

centroids, variance = kmeans(features,2)
code, distance = vq(features, centroids)

plt.figure()
ndx = np.where(code ==0)[0]
plt.plot(features[ndx,0], features[ndx,1],'*')
ndx = np.where(code ==1)[0]
plt.plot(features[ndx,0],features[ndx,1],'r.')
plt.plot(centroids[:,0],centroids[:,1],'go')
plt.axis('off')
plt.savefig("2d_clustering.jpg")

#################  problem2: Color-based Image Segmentation ###################

#1: Treat each pixels as 3-D point based on its RGB values  
    
#2: clustering them using K-means, assign each pixel to one of the clusters 
#   using vq, get cluster_id
k = 10
colors = list(map(matplotlib.colors.hex2color, random.sample(list(matplotlib.colors.cnames.values()),k)))

#zebra

imz = np.double(np.array(Image.open('zebra.jpg').convert('RGB')))

h = imz.shape[0]
w = imz.shape[1]
hw = np.reshape(imz,(h*w,3))
cen, var = kmeans(hw,k) 
cod, dis = vq(hw,cen)
cluster_idz = np.reshape(cod,(h,w))

imz = imz.tolist()

for row in range (0, h):
    for col in range (0, w):
        imz[row][col] = [x * 255 for x in colors[cluster_idz[row,col]]]
im_z = np.array(imz,dtype = uint8)
im_z = Image.fromarray(im_z,'RGB') 
im_z.save('zebra_color_clustering.jpg')


#fish 
imf = np.double(np.array(Image.open('fish.jpg').convert('RGB')))

c = imf.shape[0]
r = imf.shape[1]
cr = np.reshape(imf,(c*r,3))
cent,vari = kmeans(cr,k)
co,di = vq(cr,cent)
cluster_idf = np.reshape(co, (c,r))

imf = imf.tolist()

for i in range (0,c):
    for j in range (0,r):
        imf[i][j] = [x * 255 for x in colors[cluster_idf[i,j]]]
im_f = np.array(imf,dtype = uint8)
im_f = Image.fromarray(im_f,'RGB')
im_f.save('fish_color_clustering.jpg')

################# problem3: Texture-based Image Segmentation ##################



#zebra
z1 = array(Image.open('zebra_activation1.jpg'))
z2 = array(Image.open('zebra_activation2.jpg'))
z3 = array(Image.open('zebra_activation3.jpg'))
z4 = array(Image.open('zebra_activation4.jpg'))
z5 = array(Image.open('zebra_activation5.jpg'))
z6 = array(Image.open('zebra_activation6.jpg'))
z7 = array(Image.open('zebra_activation7.jpg'))
z8 = array(Image.open('zebra_activation8.jpg'))

zebras = np.double(np.dstack((z1,z2,z3,z4,z5,z6,z7,z8)))

height = zebras.shape[0]
weight = zebras.shape[1]
heightweight = np.reshape(zebras, (height*weight,8))
cenz, varz = kmeans(heightweight,k)
codz, disz = vq(heightweight, cenz)
zind = np.reshape(codz, (height,weight))

zebras = zebras.tolist()

for i in range (0,height):
    for j in range (0,weight):
        zebras[i][j] = [x * 255 for x in colors[zind[i,j]]]
z = np.array(zebras,dtype = uint8)
z = Image.fromarray(z,'RGB')
z.save('zebra_texture_clustering.jpg')


f1 = array(Image.open('fish_activation1.jpg'))
f2 = array(Image.open('fish_activation2.jpg'))
f3 = array(Image.open('fish_activation3.jpg'))
f4 = array(Image.open('fish_activation4.jpg'))
f5 = array(Image.open('fish_activation5.jpg'))
f6 = array(Image.open('fish_activation6.jpg'))
f7 = array(Image.open('fish_activation7.jpg'))
f8 = array(Image.open('fish_activation8.jpg'))

fishes = np.double(np.dstack((f1,f2,f3,f4,f5,f6,f7,f8)))

column = fishes.shape[0]
ro = fishes.shape[1]
columnro = np.reshape(fishes, (column*ro,8))
cenf,varf = kmeans(columnro,k)
codf,disf = vq(columnro, cenf)
find = np.reshape(codf, (column,ro))

fishes = fishes.tolist()

for x in range(0,column):
    for y in range(0,ro):
        fishes[x][y] = [ n * 255 for n in colors[find[x,y]]]
f = np.array(fishes,dtype = uint8)
f = Image.fromarray(f,'RGB')
f.save('fish_texture_clustering.jpg')





